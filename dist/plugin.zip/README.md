# Scrypted advanced notifier

https://github.com/apocaliss92/scrypted-homeassistant-utilities - For requests and bugs

 TODO
# Active streams info plugin

Provides information about the active streams

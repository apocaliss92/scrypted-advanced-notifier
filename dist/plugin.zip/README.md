# Scrypted advanced notifier

https://github.com/apocaliss92/scrypted-advanced-notifier - For requests and bugs

TODOs
- People tracking
- Battery reporting
- HA actions rule based
- Add activation conditions for a rule
- Snooze notifier-camera-class
- Tester of detections


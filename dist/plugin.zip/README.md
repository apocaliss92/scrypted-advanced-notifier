# Scrypted advanced notifier

☕️ If this extension works well for you, consider buying me a coffee. Thanks!
[Buy me a coffee!](https://buymeacoffee.com/apocaliss92)

[For requests and bugs](https://github.com/apocaliss92/scrypted-advanced-notifier)

# Getting started

## MQTT

To enable MQTT exporting:

- enable `MQTT enabled` in the general -> general tab
- setup the authentication parameters in the tab general -> MQTT, check the `Use MQTT plugin credentials` to use the credentials set on the MQTT plugin
- Check `Use NVR detections` if you want the images stored on MQTT to be the clipped ones from NVR.
- Check `Audio pressure (dB) detection` if you want a continuous reporting of the audio kept by the camera (dBs)
- Check `Check objects occupancy regularly` if you want regular occupancy data checks on the camera
- Cameras enabled to the plugin will be automatically enabled to MQTT. Can be disabled in the camera's section Advanced notifier -> Report to MQTT

The plugin will export to MQTT the following entities:

- PTZ controls
- Restart control
- Notifications enabled
- Basic detection information (motion, animal, person, vehicle, face, plate, generic object). Same information will be available for every rule associated to a camera
  - Latest image
  - Triggered
  - Last trigger time (disabled by default)
  - Amount of objects (if enabled)
- Online status
- Sleeping status
- Battery status
- Recording switch (NVR privacy mode)
- Current dBs (if enabled)

IMPORTANT
If you edit a device name, to force the correct re-creation of the ha entities you will need to delete manually the entities on HA and restart the plugin

## Notifications

The plugin provides customized way to deliver notifications. It is based on rules. Each rule can be activated based on several factors, i.e. active sensors, time ranges, security system status. Any notifier can be used but the only fully supported currently are (can be extended for any other):

- Zentik - Full round notifier application. Perfect for apple devices (iOS + watchOS, iPad, MacOS), developed by me with an eye to Advanced notifier and support whatever was possible, available for beta testing:
  - iOS under https://testflight.apple.com/join/dFqETQEm
  - PWA (android, web) under https://notifier.zentik.app
  - Scrypted plugin available https://www.npmjs.com/package/@apocaliss92/scrypted-zentik
- Native Scrypted notifiers (i.e. Scrypted iPhone app...)
- Ntfy
- Homeassistant push notifications
- Pushover
- Telegram

  Highly suggested to utilize Zentik, since it will give a nice experience for both push notifications and an history of the past one. Otherwise combinations of other notifiers can be used, Pushover or NTFY as notifiers storage, in combination with a homeassistant or NVR one, setting its priority to the lowest. This will allow to have a rich notification and also to store it on another notifier. This because notifiers such as pushover, ntfy or telegram do not have a nice support to actions. Following parameters are required to successfully send notifications

- `Scrypted token`: Token stored on the scrypted entity on homeassistant
- `NVR url`: Url pointing to the NVR instance, should be accessible from outside

Each notifier will be fully configurable on every rule, with possibility to set: actions, addSnoozeActions or priority.
Default actions can be set on every camera, will be added to each notification

All notifiers currently support critical notifications.

Notifications can be disabled for a specific camera on the camera page, Advanced notifier => Notifier => `Notifications enabled` (available on MQTT as well)
Notifications can be disabled globally on the general tab of the plugin

### Scrypted NVR notifiers

Plugins supports scripting of the NVR buitin notifiers, following features are available:

- discover to MQTT
- Notifier notifications disabled: completely disable notifications for a specific notifier
- Camera notifications disabled: disable notifications for a specific camera
- Schedule notifications on both cameras and notifiers
- Translate notifications with the plugin `Texts` section (enabled by default)
- Enable AI to generate descriptions. To make this to work, each camera and notifier should be extended with the Advanced notifier pluign and activate the AI flag on both. Reason is that ai calls can be expensive and needs to be explicitely enabled on both entities

**NVR notifiers can be used both as plugin notifiers, then with rules and everything, or just to enhance the NVR notifications.**

- If you want to use it as plugin notifier, you should keep the notifier enabled (at the very bottom of the page) BUT disable all the detection classes (on the device page of the device, i.e. `Scrypted iPhone App (user)`)
- If you want the plugin to just enhance the NVR notifications, there is nothing to change to make it work with the plugin. Just extend the notifier with this plugin and use the features you like to use

## Rules

Rules can be of following types: Detection, Occupancy, Audio, Timelapse. These properties are in common with all, some are hidden until the `Show more configurations` gets activated

- `Activation type`: when the rule shoul be active
  - Always
  - Schedule, defined in a time range during the day
  - OnActive, will be active only if the camera will be listed in the `"OnActive" devices` selector (plugin => rules => general). This selector can be driven by MQTT with a topic specified in `Active entities topic` under General => MQTT. The message to this topic can contain either a list of device IDs, names or homeassistant entityId (check homeassistant section)
- `Notifiers`: notifiers to notify, additional properties will be applied depending on the selected ones
  - `Pushover priority` priority to use on pushover
  - `Homeassistant Actions` actions to show on the homessistant push notifications, of type `{"action":"open_door","title":"Open door","icon":"sfsymbols:door"}`, check homeassistant documentation for further info
- `Open sensors` which sensors should be open to enable the rule
- `Closed sensors` which sensors should be closed to enable the rule
- `Alarm modes` which alarm states should enable the rule. The alarm system device can be defined in the plugin page under Rules => `Security system`
- `Notify with a clip` available only for detection and occupancy rules, the plugin will activate a decoder to save the last frames of the camera. On the trigger of a rule, a short clip will be generated and sent instead of a simple snapshot. It supports 2 types:
  - MP4: supported only by homeassistant and partially the others
  - GIF: supported by homeassistant, pushover

### Detection

These rules can be created for multiple cameras (on the plugin page) or per single camera. They allow to specify which object detections should trigger a notification:

- Create a new rule adding a new text in the `Detection rules` selector and hit save. A new tab will appear
- Set the activation type
- Set the notifiers to notify on the detection
- Check `Use NVR detections` to trigger the rule only as effect of detections from NVR plugin. This will include cropped images stored on MQTT and will be in sync with the NVR app events reel
- Set the detection classes and the minimum score to trigger the notification
- Set `Minimum notification delay` to debounce further notifications (overrides the camera settings)
- Set `Minimum MQTT publish delay` to debounce the image update on MQTT for this rule
- Set `Whitelisted zones` to use only detections on these zones
- Set `Blacklisted zones` to ignore detections coming from these zones
- Set `Disable recording in seconds` to enable NVR recording for some seconds and disable it afterwords
- Set a `Custom text` if a specific text should be applied. By default detection rules will use the texts defined in the plugin tab `Texts`, many placeholder are available to enrich the content
- Check `Enable AI to generate descriptions` if you want to let AI generate a description text out of the image. AI settings are available on the plugin page under the AI, currently supported: GoogleAi, OpenAi, Claude, Groq
- Set `CLIP Description` to use semantic search and filter out even more detections. It will be applied at the very end of the chain, when all the filters already had effect. Set `CLIP confidence level` to finetune the confidence level of the search
- Set `AI filter` to send the image to the choosen AI tool to confirm the input prompt
- Set `Image post processing` to process notification images:
  - MarkBoundaries will drawn a coloured rectangle around the detected object
  - Crop will crop the image around the detected object

#### Audio classification

Detection rules can also detect audio labels, i.e. crying, scream, speech etc. This will be possible adding in the detection calsses setting the "Audio" label. A new setting will appear to specify which labels to consider. The classifier to be used can be set in the Audio analysis section of the camera device:

- YAMNET ('YAMNet Audio Classification' plugin), this will be used by the plugin onboarded audio analyser
- DISABLED, no classifier will be run, external plugins will be able to still forward events, such as Frigate Bridge

Impact of the onboard classifier is relatively small and it can replace completely the smart audio sensor

### Recording (only on camera)

These rules let the cameras to record configurable videoclips. Mostly use these on camera where NVR might be overkill to be used, the app will still show the clips in a nice way

They are based on some criteria:

- detection classes, what should initially trigger the recording
- score threshold, the minimum score to trigger the recording, leave empty for any detection
- Minimum delay between clips, how many seconds to wait, at minimum, to record the following clip
- Post event seconds, how many seconds to record, at minimum, after the recording starts. The default camera prebuffer will be extra pre-event seconds on top
- Max clip length, seconds cap of the clip, following detections will prolong the original clip length
- Prolong clip on motion, prolong the clip also for simple motion events

### Occupancy (only on camera)

These rules will monitor a specific area to mark it as occupied or not

- Make sure to set an object detector on the plugin page under Rules => `Object Detector`
- Create a new rule adding a new text in the `Occupancy rules` selector and hit save. A new tab will appear
- Set the activation type
- Set the notifiers to notify on the occupancy change
- Set the detection class to monitor
- Set the camera zone to monitor, must be an `Observe` type zone defined in the `Object detection` section of the camera
- (Optional) set a capture zone to reduce the frame used for the detection, may increase success rate
- Set `Zone type`
  - `Intersect` if the objects can be considered detected if falling in any portion of the zone
  - `Contain` if the objects should be completely included in the detection zone
- Set a `Score threshold`, in case of static detections should be pretty low (default 0.3)
- Set `Occupancy confirmation`, it's a confirmation period in seconds to avoid false results. Set it depending on your specific case
- Set `Force update in seconds` to force an occupancy check if no detection happens. Any detection running on the camera will anyways check all the occupancy rules
- Set the `Max objects` the zone can contain. The zone will be marked as occupied if the detected objects are >= of the number set here
- Set a text in both `Zone occupied text` and `Zone not occupied text` for the notification texts
- Activate `Confirm occupancy with AI` to confirm occupancy results to reduce even more false positives. Under the plugin AI section is possible to customize the prompt. Results may vary depending on the model used

### Timelapse (only on camera)

Define a timeframe, the plugin will collect frames from the camera and generate a clip out of it at the end of the defined range. All the generated timelapses will be available as videoclip on the NVR app, only if the `Enable Camera` on the plugin page will be enabled.

- Create a new rule adding a new text in the `Timelapse rules` selector and hit save. A new tab will appear
- Define the week days and the start/end times. i.e. start at 11pm and end at 8am
- Set the notifiers to notify the generated clip
  - If an homeassistant notifier is used and the final clip will be <50bm, the clip will be shown as preview of the push notification!
- Set a `Notification text` for the notification message
- Set a `Frames acquisition delay`, a frame will be generated according to this. Each non-motion detection will always add a frame
  - In future will be possible to add frames based on specific detection classes and even small clips
- Set a `Timelapse framerate`, this will depend on the timespan you will chose and how long you want the final clip to be
- Use the `Generate now` button to reuse the frames collected the previous session. They will be stored until the following session starts

### Audio (only on camera)

**Audio rules will activate only if a source of audio measurement is active. The plugin provides an onboarded audio analyser, which will activate when any audio rule is running.**
Audio rules will monitor the audio received by the camera

- Create a new rule adding a new text in the `Audio rules` selector and hit save. A new tab will appear
- Set the notifiers to notify the event
- Set a `Notification text` for the notification message
- Set a `Decibel threshold` for the audio level to alert
- Set `Duration in seconds` if the audio should last at least these seconds to trigger a notification. Leave blank to notify right away

## Sequences

In the sequences section, on the plugin page, you will be able to define a custom sequence with various steps. Each sequence can contain actions such as: Wait, Script, PTZ preset, Switch on/off, Lock, Entry open/close.

Sequences can be attached to rules at different moments:

- **On-activation sequences** (rules with activation type other than Always): run when the rule becomes active.
- **On-deactivation sequences**: run when the rule becomes inactive.
- **On-trigger sequences**: run when the rule is triggered (e.g. detection matched, occupancy change).
- **On-reset sequences**: run when the rule is reset (e.g. after the trigger window ends).
- **On-generated sequences**: run when all artifacts for that rule have been generated (video clip, gif, image). Available for Detection, Occupancy and Timelapse rules.

When a sequence is run with a **payload** (e.g. On-generated), Script actions receive it as run variables. In Scrypted scripts, access it via `variables.payload`.

### Payload for On-generated sequences

For **On-generated sequences**, the payload passed to scripts has the following shape:

- **Detection and Occupancy rules**: `{ rule, videoUrl?, gifUrl?, imageUrl }`
  - `rule`: the rule object (name, notifiers, settings, etc.).
  - `videoUrl`: URL of the generated video clip (if clip type is MP4).
  - `gifUrl`: URL of the generated GIF (if clip type is GIF).
  - `imageUrl`: URL of the stored snapshot used for the notification.

- **Timelapse rules**: `{ rule, videoUrl, imageUrl, videoPath?, imagePath? }`
  - `rule`: the timelapse rule object.
  - `videoUrl`: URL to the generated timelapse video.
  - `imageUrl`: URL to the generated thumbnail image.
  - `videoPath`, `imagePath`: filesystem paths where the video and image were saved (when available).

(Initially only a few action types will be available, ask for more if you wish something more specific)

## Stored images

The plugin will store on filesystem, if configured, images for every basic detection and rule. Set the following configurations on the plugin page under the Storage tab

- `Storage path`: If set, the images used to populate MQTT topic will be also stored on the drive path

## Additional camera settings

- `Minimum snapshot acquisition delay`, minimum seconds to wait until a new snapshot can be taken from a camera, keep it around 5 seconds for cameras with weak hardware
- `Off motion duration`, amount of seconds to consider motion as ended for rules/detections affecting the camera. It will override the motion off events
- `Snapshot from Decoder`, take snapshots from the camera decoded stream. If set to `Always` it will be active only if any detection rule with videoclips, timelapse or occupancy rule is running. If set `OnMotion` it will run only during motion sessions, usefull if your camera gives many snapshot timeout errors. `Auto` will be the default and regulate it when required
- Set `Minimum notification delay` to debounce further notifications
- Set `Minimum MQTT publish delay` to debounce the image update on MQTT for this basic detections

## Webhooks

Some basic webhooks are available

### Latest snapshot

Will provide the latest registered image for each type, on the camera settings will be provided the basic url, {IMAGE_NAME} should be replaced with one of the following:

- `object-detection__{ motion | any_object | animal | person | vehicle }`
- `object-detection__{ motion | any_object | animal | person | vehicle }__{ NVR | Frigate }`
- `object-detection__face-{ known person label }`
- `object-detection__face-{ known person label }_{ NVR | Frigate }`
- `ruleImage__{ ruleName }`
- `ruleClip__{ ruleName }`
- `ruleGif__{ ruleName }`

The base path is available under each camera in the section Advanced Notifier -> Webhooks.

### POST detection images

Provide multiple urls, for each detection, POST a b64 image with some additional metadata. Filter
on some classes and define a minimum delay.

## Adanced Alarm System

The plugin provides a security system hooked into the plugin detection rules. To use it this will be required:

- Create 1 or more detection rule on the plugin page with activation type `AdvancedSecuritySystem` and set 1 or more modes to activate the rule
- Setup the provided `Advanced security system` device with preferred preferences, such as texts or devices that can be bypassed during the activation

The device is discovered on MQTT and completely compatible with Homekit.



<br/><br/><details>
<summary>Changelog</summary>

### 4.8.37

- **On-generated sequences**: new sequence hook for Detection, Occupancy and Timelapse rules. Runs when all rule artifacts (video, gif, image) have been generated. Configurable per rule under "On-generated sequences". Script actions in the sequence receive a `payload` object (e.g. `variables.payload` in Scrypted scripts) with `rule`, `videoUrl`, `gifUrl`, `imageUrl` (and for timelapse also `videoPath`, `imagePath`). Any sequence can now receive an optional payload and forward it to linked scripts.

### 4.8.36

- Setting added on every rule to allow the selection of an additional path to save artifacts, with filename {deviceId}_{ruleName}_{triggerTime}.{ext}

### 4.8.33

- Huge revamp of the Events reviewer App, added camera streams, grids and much more

### 4.8.29

- Add button to fully reset camera MQTT entities on HA and MQTT
- Added light/siren switch entities to MQTT (supported for hikvision and reolink plugins currently, ask for more plugins)
- it's suggested a full cleanup of ha devices + plugin restart

### 4.8.28

- PTZ patrol rules added. Create the new rule, add the presets to "scroll" and set the detections to let the patrol to stop

### 4.8.26

- Autolock on alarm system removed, use rule sequences instead

### 4.8.5

- Added topic for each zone + class combination for the total amount of objects detected. Will use frigate data for frigate zones if available

### 4.8.0

- Migrated to Homeassistant MQTT auto-discovery device-based. Will help to keep control on new/old entries and auto cleanup. Should migrate the plugin without any effort, if any problems, click on the new button under the main plugin page, MQTT section -> `Reset all MQTT topics`

### 4.7.11

- Frigate zones handling completed
- Frigate faces handling preparation
- Fix cleanup of recorded events not working and looping

### 4.7.10

- Audio labels standardized to be used from Frigate or onboard classifier
- Vehicle/animal labels added for Frigate source only

### 4.7.3

- New setting `Inlude user token` added in the advanced section, activate it if you face problems authenticating urls

### 4.7.2

- Allow post processing for occupancy rules
- New setting: `Show active zones`. Applies to detection and occupancy rules. If selected, the image notified will contain all the active zones during the detection matched
- New test settings: `Show active zones`, `Zones`, to allow testing of the observed zones
- New section `Active zones` in post-processing, to customize the ara shown on rule notification images

### 4.7.0

- Recording rules implemented. This is a drop-in replacement for events-recorder plugin (if you ever heard of it). Creating a new Recording Rule will let the plugin register configurable clips (including prebuffer, depends on the single camera how much it will be). This will allow to have an events based camera only when relevant events happen
- Events handling has been improved, some resources have been moved on the main storage directory, cleanups of resource optimized. It's now possible per camera to define how much space (or days) to allocate. Events have their own retention settings

### 4.6.2

- Audio analysis pipeline moved on this plugin. Basic object detector won't be necessary anymore, YAMNET remains a dependency
- Support for audio volumes dropped, Frigate/BasicObjectDetector won't be source for audio volumes anymore. If you were relying on this just drop a message, can restore if required

### 4.6.1

- Allow configuration of available modes on onobarded Alarm system

### 4.5.11

- Add possibility to select whitelisted/blacklited zones also on plugin rules

### 4.5.7

- Sequences implemented, build a custom actions sequence and activate it on a rule

### 4.5.0

- Notification images are now server through this plugin, and not cloud plugin anymore
- Rework of storing of artifacts (gifs, videos), check the README for the new webhooks syntax

### 4.4.75

- Add setting for custom origin to cover cloud plugin missing
- Fix init NVR Notifier proxy device

### 4.4.72

- Add setting to allow clip extension on repeated detections in the configured timeframe

### 4.4.70

- Added links to Zentik

### 4.4.66

- Manual AI settings removed. Use LLM plugin if that was setup before

### 4.4.59

- RPCObjects/pendingResult as measurement entities

### 4.4.58

- Add last face detection time to MQTT
- Add diagnostic values to MQTT: rpcObjects, memoryUsed, pendingResults

### 4.4.56

- Add source for faces used on people tracker as RawDetections

### 4.4.54

- Add Dev notifications setting (General -> advanced) to opt-in to communications interesting for debug purpooses

### 4.4.50

- Add support HA icon color property

### 4.4.48

- Add support for Zentik, new notifier system soon available for iOS

### 4.4.36

- Add a new setting on the extended notifier to enable the plugin for every notifications (i.e. test ones)
- Add a new setting on the extended notifier to change the payload key with the modified content, try different keys if the notifications do not contain the AI modifier payload

### 4.4.31

- Fix decoder frames resize
- Persist snoozes through reboots
- More HA properties added

### 4.4.30

- Add setting to override the decoder stream

### 4.4.29

- Add support for homeassistant channels

### 4.4.28

- Add camera setting to resize decoder frames (advanced section)
- Change `serveAssetsFromLocal` with `assetsOriginSource`

### 4.4.22

- Images name setting removed. Only latest images will be persisted
- Added `serveAssetsFromLocal` under Plugin General -> advanced, will serve all the assets links through local IP and not cloud. Useful if cloud plugin is not available or preferred local connections

### 4.4.5

- Add videoclip GIF support, this adds clips support to Pushover, NTFY and Telegram, besides the already supported Homeassistant

### 4.3.65

- Add clear action to HA actions

### 4.3.61

- Add snoozes customization (Plugin => Rules section)

### 4.3.60

- Add rule configuration to snoose any notifier of the rule, instead only the single one

### 4.3.56

- Add AI filter to detection rules

### 4.3.55

- Enable FS/Webhook images for post-processed images

### 4.3.45

- StoreEvents flag default to false

### 4.3.44

- Add customizations for post-processing actions
- Quick notifications implemented, delay should be reduced on notifications

### 4.3.41

- Publish per-zone detection entities to MQTT

### 4.3.27

- Publish audio entities to MQTT

### 4.3.25

- Add setting for homeassistant notifiers to open notifications on the homeassistant's scrypted component

### 4.3.20

- Add support to onboarded audio detections (YAMnet plugin)

### 4.3.19

- Add prompt customization for the occupancy confirmation flow

### 4.3.13

- Add setting to confirm occupancy rules with AI to avoid false positives even more

### 4.3.11

- Added support (RawDetections only) to Boundaries marking and Image cropping for notifications. NVR detections will be later on extended with this too

### 4.3.3

- Clip support added. Extend a detection rule setting a contextual description to filter even more a rule result
- LLM tools support added

### 4.2.5

- Changes prepared to use LLMPlugin. Manual is the current working way

### 4.2.4

- Secret protection added for all public endpoints. A secret is auto-generated under the section General -> Advanced, this must be used as search parameter for all webhook to avoid resources to be easily available to 3th parties. The token is now also used to serve videoclips and thumbnails with limited available tokens (3 hours)

### 4.2.0

- Events app released. It is available as dashboard link as well as PWA app. It has events and videoclips views across all the possible source (NVR, Frigate, ...). Live view is still on initial stages
- Telegram notifier supported
- Audio rules improved a lot! They will now take into account analyzed sampling values and not only peaks
- Fixed many issues when MQTT was not available initially and would crash the plugin
- Plugin will not store relevant events to make them available in the web APP

### 3.7.21

- Add detection clips to the camera clips

### 3.7.16

- Add setting to set the post event duration for videoclips

### 3.7.15

- Add MQTT data source setting per camera
- Do not wake up sleeping cameras for a snapshot

### 3.7.3

- Add configurations for videoclip speed, default to 2x (Fast)

### 3.7.0

- Add full support to Frigate detections, in combination with `Scrypted Frigate Bridge` will be possible to import frigate events into scrypted and use this plugin fully with them. Particularly interesting audio classifications and bird classification (untested, will need some test data). Snapshots are as well imported from Frigate, videoclips for accelerated GIFs will be coming soon
- Motion reporting to MQTT reduced drastically to 5 seconds
- Restructure of FS folders, old timelapses will be lost due to technical reasons
- Decoder usage changed, if any rule requires a videoclip will be permanent. If enabled on the camera for snapshots will be run only when motion is triggered
- Fix annoying MQTT bug where switch/buttons were persisted on the broker and would change state of entities randomly. Plugin will remove automatically those messages
- Add setting to alarm system for critical notifications on trigger

### 3.6.15

- Short GIF recording on detection/occupancy rules. Activate the `Notify with a clip` check to try it out. It will work very well with homeassistant notifiers

### 3.6.14

- Add notification sound customization for Pushover

### 3.6.13

- Add notification sound customization (currently only for HA notifiers)

### 3.6.12

- Decoder usage checkbox changed with a selection, Off, OnMotion (previous default), Always

### 3.6.11

- Quick actions added to alarm notifications
- Allow using active rules notfiers for alarm notifications

### 3.6.9

- [BREAKING CHANGE] Homeassistant data fetching removed. OnActive devices won't support entity IDs anymore. Use instead device id or name

### 3.6.8

- Advanced Security System released, an onboard security system mechanism linked to detection rules

### 3.6.7

- [BREAKING CHANGE] Check occupancy (in seconds) changed with a boolean flag

### 3.6.1

- Add support to camera AI generated

### 3.6.0

- Add support to NVR notifications to translations and AI messages

### 3.5.13

- Add scheduler for notifiers, can be used also for NVR notifications

### 3.5.11

- Add default actions on camera

### 3.5.10

- [BREAKING CHANGE] HaActions and priority have been removed in favour of specific settings for every notifier utilized on a rule
- Add fully support to Ntfy, Pushover, HA, Scrypted NVR for: priority (critical too), actions, snoozing

### 3.5.9

- Add full support to native NVR notifiers

### 3.5.7

- [BREAKING CHANGE] Doorbell sensors won't be used anymore, a detection class Doorbell is now available on doorbell cameras

### 3.5.6

- Add last faces detected on MQTT People tracker device

### 3.5.5

- Add POST notification webhook on notifier level

### 3.5.4

- Add main notifications switch on the plugin level

### 3.5.0

- [BREAKING CHANGE] Sensors classes have been changed, any plugin rule using lock or contact labels, shoul be changed to new ones
- Added support for Entry and Flooding sensors

### 3.4.12

- Texts building reworked. There is now only one object detection label and several object types to make it better scalable in future. Check Texts section

### 3.4.11

- Add labels (people and plates) filtering for detection rules

### 3.4.9

- Add audio detection and decoder snapshots entities to MQTT
- Enable decoder only during motion events

### 3.4.8

- Add support for NVR notifiers to enable/disable notifications globally or per camera, if the camera flag is off. This allows to script NVR notifications without implementing any rule
- Notifiers device discovered on MQTT

### 3.4.1

- Add setting to enable snoozing actions on a notifier (Pushover and homeassistant)

### 3.4.0

- Latest snapshots webhook changed, add a Webhook section to the README with all the possible snapshots available
- Added POST webhook for detections, set multiple URL and preferred cameras to send images to external services

### 3.3.7

- Add setting to disable notifications for a specific camera, on MQTT as well
- Implement snooze actions on Homeassistant notifiers

### 3.3.6

- Any object entities added on MQTT and file system, will be triggered for any object detection (animal, vehicle, person)

### 3.3.1

- Occupancy data persisting improved. Current status and detected objects added to settings.
  Should fix false resetting on startup

### 3.2.0

- Update images for rule in the same asynqueue to make sure an image is always available

### 3.1.23

- Link plugin rule entities on devices and vice-versa, plugin triggers will activate the plugin entity as well

### 3.1.17

- Fix retained button messages not cleaned up

### 3.1.15

- Only update motion in case of non-NVR detections when NVR detections is enabled

### 3.1.10

- Move MQTT enabled setting on camera level, enabled by default
- Move Notifier enabled setting on notifier level, enabled by default

### 3.1.9

- Added option to fetch frames from prebuffer. Unsuggested for use, use it only if snapshot crashes continuously

### 3.0.31

- Automatic cleanup of HA entities when not available anymore

### 3.0.30

- `Minimum MQTT publish delay` setting adding on the camera, allowing to defer detection updates

### 3.0.28

- NVR images will be stored on system as well, with a -NVR suffix, along with the non-cropped ones

### 3.0.27

- Add camera level configuration to enable regular occupancy check

### 3.0.23

- Add rule configuration to delay MQTT image update

### 3.0.21

- Cleanup detection rules discovery not supported per camera

### 3.0.20

- Fix NVR detections parsing

### 3.0.19

- Performance noticeably improved splitting images update on MQTT in batches

### 3.0.17

- MQTT client split per device to reduce overhead for weak brokers
- Utilize images from object detectors when available
- Optimize image usage

### 3.0.8

Added support to Groq

### 3.0.7

Added support to Anthropic AI

### 3.0.6

Added support to Google AI, thanks @sfn!

### 3.0.0

MQTT rework. Most of the IDs have changed. Remove all the homeassistant devices and let the plugin to recreate them.
This was required to allow me to extend the plugin in an easier and scalable way. Some improvements happened along the way

### 2.2.30

Add MQTT flag for each rule currently running

### 2.2.28

Enable reporting of occupancy data for every camera enabled to MQTT

### 2.2.27

Audio deteciton rules implemented

### 2.2.26

Add PTZ controls to MQTT/HA

### 2.2.25

Add Reboot button to MQTT/HA

</details>
